<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Email COnfiguration
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'gains.enterpriselinuxcloud.com';

$config['smtp_port'] = 465;
$config["smtp_crypto"] = "ssl";

// $config['smtp_port'] = 587;
// $config["smtp_crypto"] = "tls";


$config['smtp_user'] = 'notifications@workinghours.com.au';
$config['smtp_pass'] = '@Workinhours';
$config['mailtype'] = 'html';
$config['smtp_timeout'] = '500';

$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;

defined('BASEPATH') OR exit('No direct script access allowed');

