<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Email COnfiguration
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'gains.enterpriselinuxcloud.com';

$config['smtp_port'] = 465;
$config["smtp_crypto"] = "ssl";

// $config['smtp_port'] = 587;
// $config["smtp_crypto"] = "tls";


$config['smtp_user'] = 'notifications@workinghours.com.au';
$config['smtp_pass'] = '@Workinhours';
$config['mailtype'] = 'html';
$config['smtp_timeout'] = '500';

$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;


/* End of file email.php */
/* Location: ./application/config/email.php */
defined('BASEPATH') OR exit('No direct script access allowed');

/*// Email COnfiguration
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'sg3plcpnl0148.prod.sin3.secureserver.net';

$config['smtp_port'] = 465;
$config["smtp_crypto"] = "ssl";
$config['smtp_timeout'] = 30;

// $config['smtp_port'] = 587;
// $config["smtp_crypto"] = "tls";


$config['smtp_user'] = 'notifications@savemyassign.com';
$config['smtp_pass'] = '@Save3103';
$config['mailtype'] = 'html';
$config['charset'] = 'iso-8859-1';
$config['wordwrap'] = TRUE;*/