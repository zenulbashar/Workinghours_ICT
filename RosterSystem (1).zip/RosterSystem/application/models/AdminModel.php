<?php
defined('BASEPATH') OR exit('No direct script access allowed');

	class AdminModel extends CI_Model{

	public function __construct()
	{
		$this->load->database();
	}
	public function getCompanies()
	{
		$result=$this->db->get('company_mst');
		return $result->result();

	}
		public function loginAdmin($email,$password)
	{
		$this->db->where('admin_email',$email);
		$this->db->where('admin_password',$password);
		$result=$this->db->get('admin_mst');
		return $result->result();
	}
	public function getEmployees()
	{
		$result=$this->db->get('employee_mst');
		return $result->result();
	}
	public function getFeedbackCompanies()
	{
		$result=$this->db->get('feedback_companies');
		return $result->array();
	}
	public function getFeedbackEmployees()
	{
		$result=$this->db->get('feedback_employees');
		return $result->array();
	}
	public function getContact()
	{
		$result=$this->db->get('tbl_contact');
		return $result->result();
	}
	public function countCompanies()
	{
		  return $this->db->count_all("company_mst");
	}
	public function countEmployees()  
	{
		  return $this->db->count_all("employee_mst");
	}
	public function countRosters()
	{
		  return $this->db->count_all("roster_mst");
	}
	public function removeCompany($id)
	{
		$this->db->where('company_id',$id);
		$this->db->delete('company_mst');
		return true;
		
	}
	public function removeEmployee($id)
	{
		$this->db->where('employee_id',$id);
		$this->db->delete('employee_mst');
		return true;
	}
	public function count_companies()
	{
		
        $this->db->get('assignment_mst');
       	return $this->db->count_all_results();
        
    
	}
	public function EmployeeFeedback()
	{
		$res=$this->db->get('feedback_employees');
		return $res->result();
	}
	public function CompanyFeedback()
	{
		$res=$this->db->get('feedback_companies');
		return $res->result();
	}
	
	
}
?>
