
<!DOCTYPE HTML>
<html>

<head>
	<title>Log Book Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- Custom Theme files -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets3/css/jquery-ui.css" />
	<link href="<?php echo base_url();?>assets3/css/style.css" rel='stylesheet' type='text/css' />
	<!--fonts-->
	<link href="//fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
	<!--//fonts-->
</head>

<body>
    <header>
        <h2 class="text-center;font-size=30px;" style="color:red;">Welcome!! <?php echo $this->session->userdata('employee_fname');?> To Your Log Book Page</h2>
		<img style="float: right;margin-top: -105px;border-radius: 20%;width: 8%;margin-right: 13;" width="100px"src="<?php echo base_url('uploads/');?><?php echo $this->session->userdata('employee_image'); ?>">
    </header>
	<!--background-->
	<h1 style="color:red;font-family:times new roman;">Log Book</h1>
	<div class="main-w3layouts-content">
		<div class="top-section">
			<h2 class="sub-hdng-agileits-w3layouts">Report Us</h2>
			<p>Please fill the form below about the incident</p>
		</div>
		<div class="w3-agile-login-form">
		<?php foreach($res as $row) { ?>
			<form action="<?php echo base_url();?>index.php/Welcome/addLogDetail" method="post" >
				<h3 class="inner-hdng-agileinfo">Contact information</h3>
				<div class="top-fields-wthree">
					<div class="input-fields-w3ls">
						<input type="hidden" name="employee_id" value="<?php echo $this->session->userdata('employee_id')?>">
						<input type="hidden" name="roster_id" value="<?php echo $row->id;?>">
							<input type="hidden" name="company_id" value="<?php echo $row->company_id;?>">
						<input type="text" name="employee_name" value="<?php echo $row->employee_fname; ?> " required="" readonly="true" />
					</div>
					<div class="input-fields-w3ls">
						<input type="email" name="employee_lname" value="<?php echo $row->employee_lname?>" required="" readonly="true" />
					</div>
					<div class="input-fields-w3ls">
						<input type="text" name="employee_email" value="<?php echo $row->employee_email; ?>" required="" readonly="true" />
					</div>
				</div>
				<h3 class="inner-hdng-agileinfo">Company Information</h3>
				<div class="top-fields-wthree">
					<div class="input-fields-w3ls">
						<input type="text" name="company_name" value="<?php echo $row->company_name; ?>" required="" readonly="true"/>
					</div>
					<div class="input-fields-w3ls">
						<input type="email" name="roster_title"  value="<?php echo $row->roster_title; ?>" required="" readonly="true" />
					</div>
					<div class="input-fields-w3ls">
						<input type="text" name="location" value="<?php echo $row->location; ?>" required="" readonly="true" />
					</div>
				</div>
				<h3 class="inner-hdng-agileinfo">Log Details</h3>
				<div class="mid-fields-agileits-w3layouts">
					<div class="input-fields-w3ls2">
						
					</div>
					<div class="input-fields-w3ls2">
						<select id="country" name="status" onchange="change_country(this.value)" class="frm-field required" required="">
							<option value="" disabled selected>Status</option>
							<option value="0">In Process</option>
							<option value="3">Completed</option>
						</select>

					</div>
				</div>
				<textarea name="description" placeholder="Log Description" required=""></textarea>
		
				<input type="submit" value="Report Now">
			
			</form>
		<?php } ?>
		
			
		</div>
	</div>
	<div class="clear"></div>

	<!-- JavaScript plugins -->
	<script type="text/javascript" src="<?php echo base_url();?>assets3/js/jquery-2.2.3.min.js"></script>

	<!-- Calendar -->
	<script src="<?php echo base_url();?>assets3/js/jquery-ui.js"></script>
	<script>
		$(function () {
			$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
		});
	</script>
	<!-- //Calendar -->
	<!--// JavaScript plugins -->
</body>

</html>