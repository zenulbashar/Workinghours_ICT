
	<!-- //header -->
	<!-- banner -->
	<section class="banner-1">
	</section>
	<!-- //banner -->
	<!-- about -->
	<section class="welcome py-5">
		<div class="container py-md-4 mt-md-3">
			<h2 class="heading-agileinfo">About Us <span>Speed Up the Work Process</span></h2>
			<span class="w3-line black"></span>
			<div class="row about-tp mt-md-5 pt-5">
				<div class="col-lg-6 welcome-left">
					<h4 style="color:red;">Welcome To The Roster Management System</h4>
					<h4>The roster system is an online platform which provides 
						the employers to manage their employees. 
						The task which is allocated to the employees can be maintained.
						 The time and place of their next job can be updated. 
						The employee will get and update about the next job via mail.  
						The employee can also check the roster for the current and 
						previously done tasks. The upcoming tasks can also be shown so that 
						they can get ready for it. Also the incidents can be reported 
						while the working hours and also some sequence of tasks t
						hey did in similar way as a log.
						
					<p>
						<h4 style="color:blue;text-align:center;">Employer</h4> 
						Any person who owns company or industry 
						and has number of employee having skills about some particular 
						domain and need to maintain the employees.
						<h4 style="color:blue;text-align:center;">Employee</h4> 
						Any individual who has some particular skill and need to work.
						<h4 style="color:blue;text-align:center;">Portfolio:</h4> 
						An online page which consists of an employee profile    and a 
						timeline of his content.
						<h4 style="color:blue;text-align:center;">Profile</h4> 
						Description of employee which shows of the personal details</h4>
						</p>
				</div>
				<div class="col-lg-6 welcome-right">
					<div class="welcome-right-top">
						<img src="<?php echo base_url();?>assets2/images/g1.jpg" alt="" class="img-fluid">
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- //about -->


	

