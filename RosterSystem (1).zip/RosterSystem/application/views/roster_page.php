
<!DOCTYPE HTML>
<html lang="zxx">

<head>
    
    <!-- Meta-Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Multi Range Calendar a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- //Meta-Tags -->
   
    <!-- calendar css -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets4/css/pignose.calendar.min.css" />
    <!-- online fonts -->
    
</head>

<body>
   <body id="login">
 
 <header>
        <h2 class="text-center;font-size=30px;" style="color:red;">Welcome!! <?php echo $this->session->userdata('employee_fname');?> Your Roster Page</h2>
		<img style="float: right;margin-top: -105px;border-radius: 20%;width: 8%;margin-right: 13;" width="100px"src="<?php echo base_url('uploads/');?><?php echo $this->session->userdata('employee_image'); ?>">
    </header>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div><div>
		page in maintanance
	</div><div>
		page in maintanance
	</div><div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div><div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div>
	<div>
		page in maintanance
	</div><div>
		page in maintanance
	</div>
	
	
	

</body>

</html>