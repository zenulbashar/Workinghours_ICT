
<!DOCTYPE HTML>
<html>

<head>
	<title>Incident Report Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- Custom Theme files -->
	
	
	<!--fonts-->
	<link rel="stylesheet" href="<?php echo base_url();?>assets3/css/jquery-ui.css" />
	<link href="<?php echo base_url();?>assets3/css/style.css" rel='stylesheet' type='text/css' />
	<!--fonts-->
	
			<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css" />
	<!--//fonts-->
	
	  </head>

<body id="login">
    <header>
        <h2 class="text-center;font-size=30px;" style="color:red;">Welcome!! <?php echo $this->session->userdata('employee_fname');?> Your Incident Report Page</h2>
		
    </header>
	<!--background-->
	<h1 style="color:red;font-family:times new roman;">Incident Report Form</h1>
	<div class="main-w3layouts-content">
		<div class="top-section">
			<h2 class="sub-hdng-agileits-w3layouts">Report Us</h2>
			<p>Please fill the form below about the incident</p>
		</div>
		<div class="w3-agile-login-form">
		<?php foreach($res as $row) { ?>
			<form action="<?php echo base_url();?>index.php/Welcome/addIncident" method="post" >
				<h3 class="inner-hdng-agileinfo">Contact information</h3>
				<div class="top-fields-wthree">
					<div class="input-fields-w3ls">
						<input type="hidden" name="employee_id" value="<?php echo $this->session->userdata('employee_id')?>">
						<input type="text" name="employee_name" value="<?php echo $row->employee_fname?> <?php echo $row->employee_lname?>" required="" />
					</div>
					<div class="input-fields-w3ls">
						<input type="email" name="employee_email" value="<?php echo $row->employee_email;?>" required="" />
					</div>
					<div class="input-fields-w3ls">
						<input type="text" name="employee_contactNo" placeholder="Contact Number" required="" />
					</div>
				</div>
				<h3 class="inner-hdng-agileinfo">Company Information</h3>
				<div class="top-fields-wthree">
					<div class="input-fields-w3ls">
						<input type="text" name="company_name" value="<?php echo $row->Company_to_join;?>" required="" />
					</div>
					<div class="input-fields-w3ls">
						<input type="email" name="company_email" placeholder="Company Email" required="" />
					</div>
					<div class="input-fields-w3ls">
						<input type="text" name="company_location" placeholder="Company Location" required="" />
					</div>
				</div>
				<h3 class="inner-hdng-agileinfo">About Incident</h3>
				<div class="mid-fields-agileits-w3layouts">
					<div class="input-fields-w3ls2">
						<div class="input-fields-w3ls2">
						<span style="color:#ffd877;">Date of Incident</span><input type="text" id="datepicker4" name="date_Incident" placeholder="Click Here" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Date';}" required="" style="background:grey;"/>
					</div>
					</div>
					<div class="input-fields-w3ls2">
						<select id="country" name="level_Incident" onchange="change_country(this.value)" class="frm-field required" required="">
							<option value="">Incident level</option>
							<option value="High">High</option>
							<option value="Medium">Medium</option>   
							<option value="Low">Low</option>     
						</select>

					</div>
				</div>
				<textarea name="description_Incident" placeholder="Description of Incident" required=""></textarea>
				<textarea name="location_Incident" placeholder="Location of Incident" required=""></textarea>
				<input type="submit" value="Report Now">
			</form>
		<?php } ?>
		</div>
	</div>
	<div class="clear"></div>

	<!-- JavaScript plugins -->
	<script type="text/javascript" src="<?php echo base_url();?>assets3/js/jquery-2.2.3.min.js"></script>

	<!-- Calendar -->
	<script src="<?php echo base_url();?>assets3/js/jquery-ui.js"></script>
	<script>
		$(function () {
			$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
		});
	</script>
	
	 <script>
 $(function() {
    $( "#datepicker4" ).datepicker({
      dateFormat: 'yy-mm-dd',
    
    });
  } );
 </script>
	<!-- //Calendar -->
	<!--// JavaScript plugins -->
</body>

</html>