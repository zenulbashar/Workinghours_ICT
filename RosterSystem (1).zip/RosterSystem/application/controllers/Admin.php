<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {


	 public function __construct(){
		 parent::__construct();
		 $this->load->model('AdminModel');
		 $this->load->helper(array('form','url','file'));
		 $this->load->library('session');
	 }
	 public function index()
	 {
		 $this->load->view('admin/header');
		 $this->load->view('admin/login_admin');
	 }

		 public function isLoginAdmin()
		 {
			$email=$this->input->post('admin_email');
			$password=$this->input->post('admin_password');
			$result=$this->AdminModel->loginAdmin($email,$password);
			if(count($result)>0)
			{
				foreach($result as $row)
				{
					$sessionArray=array(
					'id'=>$row->id,
					'admin_name'=>$row->admin_name);
				}
				$this->session->set_userdata($sessionArray);
				redirect('Admin/dashboard');

			} 
			else
			{
				$this->session->set_flashdata('success','Incorrect Email or Password!');
				redirect('Admin/');
			}

	 }
	 public function dashboard()
	 {
		 $data['c_emp']=$this->AdminModel->countEmployees();
		 $data['c_comp']=$this->AdminModel->countCompanies();
		 $data['c_roster']=$this->AdminModel->countRosters();
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/admin_Welcome',$data);
	 }
	 public function loadFeedback_company()
	 {
		 $data['result']=$this->AdminModel->CompanyFeedback();
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_feedbacks_company',$data);
	 }
	 public function loadFeedback_employee()
	 {
	     $data['result']=$this->AdminModel->EmployeeFeedback();
		
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_feedbacks_employee',$data);
	 }
	 public function loadCompanies()
	 {
		 $result=$this->AdminModel->getCompanies();
		 $data['result']=$result;

		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_companies',$data);
	 }
	 public function loadEmployees()
	 {
		 $result=$this->AdminModel->getEmployees();
		 $data['result']=$result;
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_employees',$data);
	 }
	 public function loadContact()
	 {
		 $result=$this->AdminModel->getContact();
		 $data['result']=$result;
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_contacts',$data);
	 }
	 public function removeCompany()
	 {
		 $id=$this->input->get('company_id');
		 $res=$this->AdminModel->removeCompany($id);
		 if($res){
			 redirect('Admin/loadCompanies/');
		 }
		 else{
			 echo "Error";
		 }
		 
	 }
	 public function removeEmployee()
	 {
		 $id=$this->input->get('employee_id');
		 $res=$this->AdminModel->removeEmployee($id);
		 if($res){
			 redirect('Admin/loadEmployees');
		 }
		 else{
			 echo "Error";
		 }
	 }
	 public function removeRoster()
	 {
		 $id=$this->input->get('roster_id');
		 $this->AdminModel->removeRoster($id);
	 }
	 public function removeFeedback()
	 {
		 $id=$this->input->get('feedback_id');
		 $this->AdminModel->removeFeedback($id);
	 } 
 }
