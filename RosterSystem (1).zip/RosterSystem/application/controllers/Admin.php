<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {


	 public function __construct(){
		 parent::__construct();
		 $this->load->model('AdminModel');
		 $this->load->helper(array('form','url','file'));
		 $this->load->library('session');
	 }
	 public function index()
	 {
		 $this->load->view('admin/header');
		 $this->load->view('admin/login_admin');
	 }

		 public function isLoginAdmin()
		 {
			$email=$this->input->post('admin_email');
			$password=$this->input->post('admin_password');
			$result=$this->AdminModel->loginAdmin($email,$password);
		if(count($result)>0)
		{
			foreach($result as $row)
			{
				$sessionArray=array(
				'id'=>$row->id,
				'admin_name'=>$row->admin_name);
			}
			$this->session->set_userdata($sessionArray);
			$this->dashboard();

		} 
		else
		{
			$this->session->set_flashdata('success','Incorrect Email or Password!');
			redirect('Admin/');
		}

	 }
	 public function dashboard()
	 {
		 $data['c_emp']=$this->AdminModel->countEmployees();
		 $data['c_comp']=$this->AdminModel->countCompanies();
		 $data['c_roster']=$this->AdminModel->countRosters();
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/admin_Welcome');
	 }
	 public function loadFeedback_company()
	 {
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_feedbacks_company');
	 }
	 public function loadFeedback_employee()
	 {
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_feedbacks_employee');
	 }
	 public function loadCompanies()
	 {
		 $result=$this->AdminModel->getCompanies();
		 $data['result']=$result;

		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_companies',$data);
	 }
	 public function loadEmployees()
	 {
		 $result=$this->AdminModel->getEmployees();
		 $data['result']=$result;
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_employees',$data);
	 }
	 public function loadContact()
	 {
		 $result=$this->AdminModel->getContact();
  	 	$data['result']=$result;
		 $this->load->view('admin/header_admin');
		 $this->load->view('admin/view_contacts',$data);
	 }
	 
 }
