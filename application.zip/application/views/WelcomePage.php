	<section class="banner">
		<div class="callbacks_container">
			<ul class="rslides" id="slider3">
				<li>
					<div class="slider-info bg1">
						<div class="banner-text container">
							<h4 class="movetxt text-left mb-3 agile-title text-capitalize">Love your Work!</h4>
							<p class="text-white mb-3">In Roster Management System</p>
							<a class="bt text-capitalize" href="<?php echo base_url();?>assets2/about.html" role="button"> read more
								<i class="fas fa-angle-double-right"></i>
							</a>
						</div>
					</div>
				</li>
				<li>
					<div class="slider-info bg2" style="background-size:cover;">
						<div class="banner-text container">
							<h4 class="movetxt text-left mb-3 agile-title text-capitalize">Join where you belong</h4>
							<p class="text-white mb-3">In Roster Management System</p>
							<a class="bt text-capitalize" href="<?php echo base_url();?>assets2/about.html" role="button"> read more
								<i class="fas fa-angle-double-right"></i>
							</a>
						</div>
					</div>
				</li>
				<li>
					<div class="slider-info bg3" >
						<div class="banner-text container">
							<h4 class="movetxt text-left mb-3 agile-title text-capitalize">Perform your tasks</h4>
							<p class="text-white mb-3">In Roster Management System</p>
							<a class="bt text-capitalize" href="<?php echo base_url();?>assets2/about.html" role="button"> read more
								<i class="fas fa-angle-double-right"></i>
							</a>
						</div>
					</div>
				</li>
			</ul>
		</div>
	</section>
	<!-- //banner -->
	<!-- Products -->
	<section class="services py-5">
		<div class="container py-md-4 mt-md-3"> 
			<h2 class="heading-agileinfo">Working of our system <span>Speed Up the Working process</span></h2>
			<span class="w3-line black"></span>
			<div class="row inner_w3l_agile_grids-1 mt-md-5 pt-4">
				<div class="col-md-4 w3layouts_news_left_grid1">
					<div class="new_top">
						<i class="fa fa-tasks"></i>			
						<h3 class="mb-3 mt-3">1.Sing-up As Company</h3>
						<p>You need to sign-up as a company first after that employees will join you </p>
					</div>
				</div>
				<div class="col-md-4 w3layouts_news_left_grid2">
					<div class="new_top">
						<i class="fa fa-tasks" ></i>
						<h3 class="mb-3 mt-3">2.Sign-up As Employee</h3>
						<p>Give your personal details along with a company you want to join</p>
					</div>
				</div>
				<div class="col-md-4 w3layouts_news_left_grid3">
					<div class="new_top">
						<i class="fa fa-tasks"></i>
						<h3 class="mb-3 mt-3">3.Task Allocation</h3>
						<p>After login process you can see the tasks your company want to perform with you</p>
					</div>
				</div>
			</div>
			
	</div>   
</section>
<!--footer-->
	