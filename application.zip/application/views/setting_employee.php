
<!DOCTYPE HTML>
<html>

<head>
	<title>Incident Report Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- Custom Theme files -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets3/css/jquery-ui.css" />
	<link href="<?php echo base_url();?>assets3/css/style.css" rel='stylesheet' type='text/css' />
	<!--fonts-->
	<link href="//fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600" rel="stylesheet">
	<!--//fonts-->
</head>

<body>
    <header>
        <h2 class="text-center;font-size=30px;" style="color:red;">Welcome!! <?php echo $this->session->userdata('employee_fname');?> To Your Profile Page</h2>
		<img style="float: right;margin-top: -105px;border-radius: 20%;width: 8%;margin-right: 13;" width="100px"src="<?php echo base_url('uploads/');?><?php echo $this->session->userdata('employee_image'); ?>">
    </header>
	<!--background-->
	<h1 style="color:red;font-family:times new roman;text-shadow:2px 5px 3px black">Profile</h1>
	<div class="main-w3layouts-content">
		<div class="top-section">
			<h2 class="sub-hdng-agileits-w3layouts">View Of Your Profile</h2>
			<p>Click edit to change profile information</p>
		</div>
		<div class="w3-agile-login-form">
		<?php foreach($res as $row) { ?>
			<form action="<?php echo base_url();?>index.php/Welcome/addIncident" method="post" >
			<h3 class="inner-hdng-agileinfo">Profile Picture</h3>
				<img  style="border-radius: 20%;width: 200px;" width="200px" src="<?php echo base_url('uploads/');?><?php echo $row->employee_image; ?>">
				<h3 class="inner-hdng-agileinfo">General information</h3>
				<div class="top-fields-wthree">
					<div class="input-fields-w3ls">
						<input type="hidden" name="employee_id" value="<?php echo $this->session->userdata('employee_id');?>">
						<input type="text" name="employee_name" value="<?php echo $row->employee_fname; ?>" readonly="true" />
					</div>
					<div class="input-fields-w3ls">
						<input type="email" name="employee_email" value="<?php echo $row->employee_lname; ?>" readonly="true" />
					</div>
					<div class="input-fields-w3ls">
						<input type="text" name="employee_contactNo" value="<?php echo $row->birth_date; ?>" readonly="true" />
					</div>
				</div>
				<h3 class="inner-hdng-agileinfo">Contact Information</h3>
				<div class="top-fields-wthree">
					<div class="input-fields-w3ls">
						<input type="text" name="company_name" value="<?php echo $row->employee_gender; ?>" readonly="true" />
					</div>
					<div class="input-fields-w3ls">
						<input type="email" name="company_email" value="<?php echo $row->employee_email; ?>" readonly="true" />
					</div>
					<div class="input-fields-w3ls">
						<input type="text" name="company_location" value="<?php echo $row->employee_password; ?>" readonly="true" />
					</div>
				</div>
				<h3 class="inner-hdng-agileinfo">Address Information</h3>
				<div class="mid-fields-agileits-w3layouts">
							<textarea name="description_Incident" value="<?php echo $row->employee_address; ?>" readonly="true"><?php echo $row->employee_address; ?></textarea>
					
				</div>
	
				<a href="<?php echo base_url();?>index.php/Welcome/EditProfile/?employee_id=<?php echo $this->session->userdata('employee_id');?>">Edit Profile</a>
			</form>
		<?php } ?>
		</div>
	</div>
	<div class="clear"></div>

	<!-- JavaScript plugins -->
	<script type="text/javascript" src="<?php echo base_url();?>assets3/js/jquery-2.2.3.min.js"></script>

	<!-- Calendar -->
	<script src="<?php echo base_url();?>assets3/js/jquery-ui.js"></script>
	<script>
		$(function () {
			$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
		});
	</script>
	<!-- //Calendar -->
	<!--// JavaScript plugins -->
</body>

</html>